import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-promotions',
  templateUrl: './promotions.component.html',
  styleUrls: ['./promotions.component.css']
})
export class PromotionsComponent implements OnInit {
   Emails:any;
  constructor(private http:HttpClient,private route:Router,private Activatedroute:ActivatedRoute,private emailservice:EmailsService) { }
   email:any;
  ngOnInit(): void {
    this.email=this.Activatedroute.snapshot.params['id'];
    this.emailservice.getAllmails().subscribe((res)=>{
    this.Emails=res;
    }); 
  }

}
