import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-detailedmail',
  templateUrl: './detailedmail.component.html',
  styleUrls: ['./detailedmail.component.css']
})
export class DetailedmailComponent implements OnInit {
  Email:any;
  constructor(private http:HttpClient,private route:Router,private Activateroute:ActivatedRoute,private emailservice:EmailsService) { }
  email:any;
  ngOnInit(): void {
    this.email=this.Activateroute.snapshot.params['id'];
    console.log(this.email);
    this.emailservice.getAllmails().subscribe((res)=>{
   this.Email=res;
    });
  }

}
