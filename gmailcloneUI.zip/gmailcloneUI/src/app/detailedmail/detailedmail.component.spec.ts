import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailedmailComponent } from './detailedmail.component';

describe('DetailedmailComponent', () => {
  let component: DetailedmailComponent;
  let fixture: ComponentFixture<DetailedmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailedmailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetailedmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
