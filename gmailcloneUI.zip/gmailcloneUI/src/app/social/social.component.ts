import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.css']
})
export class SocialComponent implements OnInit {
  Emails:any;
  constructor(private http:HttpClient,private emailservice:EmailsService,private router:Router,private activatedroute:ActivatedRoute) { }
  email:any;
  ngOnInit(): void {
   this.email=this.activatedroute.snapshot.params['id'];
   this.emailservice.getAllmails().subscribe((res)=>{
     this.Emails=res;
   });
  }

}
