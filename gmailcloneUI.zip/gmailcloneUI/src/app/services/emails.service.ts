import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmailsService {

  constructor(private http: HttpClient) { }
  getAllmails(): Observable<any> {
    return this.http.get<any>('https://localhost:7208/api/email');
  }
  
  addmaildata(data: any) {
    console.log(data);
    return this.http.post('https://localhost:7208/api/email', data, { headers: { 'ContentType': 'application/json' } })
  }
}
