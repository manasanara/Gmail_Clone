import { TestBed } from '@angular/core/testing';

import { EmailcountService } from './emailcount.service';

describe('EmailcountService', () => {
  let service: EmailcountService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailcountService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
