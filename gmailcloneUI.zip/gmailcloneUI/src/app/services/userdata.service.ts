import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {
  baseapiurl :string = environment.baseApiUrl;
  constructor(private http:HttpClient) { }

  getAllusers():Observable<any>{
      return this.http.get<any>('https://localhost:7208/api/userdata');
    }
    adduserdata(data:any){
      return this.http.post('https://localhost:7208/api/userdata',data)
    }
    get_Userid(email:string):Observable<string> {
     return this.http.get<any>('${https://localhost:7094/api/userdata/}+${email}');
    }
}
