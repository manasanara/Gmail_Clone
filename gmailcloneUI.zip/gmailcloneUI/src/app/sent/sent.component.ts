import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.css']
})
export class SentComponent implements OnInit {
  Emails:any;
  constructor(private http:HttpClient,private route:Router,private activatedroute:ActivatedRoute,private emailservice:EmailsService) { }
  email:any;
  ngOnInit(): void {
  this.email=this.activatedroute.snapshot.params['id'];
  this.emailservice.getAllmails().subscribe((res)=>{
    this.Emails=res;
  })
  }

}
