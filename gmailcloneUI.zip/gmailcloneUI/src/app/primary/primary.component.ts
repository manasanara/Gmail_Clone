import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-primary',
  templateUrl: './primary.component.html',
  styleUrls: ['./primary.component.css']
})
export class PrimaryComponent implements OnInit {
  Emails:any;
  constructor(private http:HttpClient,private emailservice:EmailsService,private route:Router,private Activateroute:ActivatedRoute) { }
  email:any;
  ngOnInit(): void {
   this.email=this.Activateroute.snapshot.params['id'];
   this.emailservice.getAllmails().subscribe((res)=>{
    this.Emails=res;
   });
  }

}
