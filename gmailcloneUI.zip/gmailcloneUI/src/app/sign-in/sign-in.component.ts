import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import ValidateForm from '../helpers/validatorform';
import { UserdataService } from '../services/userdata.service';
import { HomeComponent } from '../home/home.component';
@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
   signform! : FormGroup;
   Email:any={};
   particularemail:any;
  constructor(public router:Router,public ActivatedRoute:ActivatedRoute,private fb:FormBuilder,private userdata:UserdataService) { }
  openmails(){
    this.router.navigate(['home/',this.signform.value.email]);
     //adding userdata
     const userdata ={
      email:this.signform.value.email,
      password :this.signform.value.password,
    }
    if(this.signform.valid){
      this.userdata.getAllusers().subscribe(res=>{
       this.Email=res;
       console.log(this.Email);
        alert("logged in Successful");
      })
     }
    else{
      console.log("form is not valid")
        // throw the error using toaster and with required fields
        ValidateForm.validateAllFormFields(this.signform);
        alert("your form is invalid");
    }
  }
  userid:any;
  usermail:any;
  ngOnInit(): void {
    this.signform = this.fb.group({
      email : ['',Validators.required],
      password :['',Validators.required]
    })
    this.usermail=this.signform.value.email;
  }
}
