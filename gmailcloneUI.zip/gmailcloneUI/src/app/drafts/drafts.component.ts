import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';

@Component({
  selector: 'app-drafts',
  templateUrl: './drafts.component.html',
  styleUrls: ['./drafts.component.css']
})
export class DraftsComponent implements OnInit {
  Emails:any;
  constructor(private http:HttpClient,private route:Router,private Activateroute:ActivatedRoute,private emailservice:EmailsService) { }
  email:any;
  ngOnInit(): void {
    this.email=this.Activateroute.snapshot.params['id'];
    this.emailservice.getAllmails().subscribe((res)=>{
     this.Emails=res;
    });
  }

}
