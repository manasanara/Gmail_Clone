import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MailsComponent } from './mails/mails.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ComposemailComponent } from './composemail/composemail.component';
import { HomeComponent } from './home/home.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { PrimaryComponent } from './primary/primary.component';
import { PromotionsComponent } from './promotions/promotions.component';
import { SocialComponent } from './social/social.component';
import { InboxComponent } from './inbox/inbox.component';
import { DraftsComponent } from './drafts/drafts.component';
import { SentComponent } from './sent/sent.component';
import { DetailedmailComponent } from './detailedmail/detailedmail.component';
const routes: Routes = [
  // {path:'login/:id',component:LoginComponent},
  // {path:'userregistration',component:UserregistrationComponent},
  // {path:'userdata',component:UserdataComponent},
  // {path:'success',component:SuccessComponent},
  // {path:'editdata',component:EditdataComponent},
  // {path:'',redirectTo:'/home',pathMatch:'full'}
  {path:'signup',component:SignUpComponent},
  {path:'composemail',component:ComposemailComponent},
  {path:'mails',component:MailsComponent},
  {path:'home/:id',component:HomeComponent},
  {path:'signin',component:SignInComponent},
  {path:'primary/:id',component:PrimaryComponent},
  {path:'promotions/:id',component:PromotionsComponent},
  {path:'social/:id',component:SocialComponent},
  {path:'inbox/:id',component:InboxComponent},
  {path:'drafts/:id',component:DraftsComponent},
  {path:'sent/:id',component:SentComponent},
  {path:'detailedmail/:id',component:DetailedmailComponent},
  {path:'',redirectTo:'signup',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
