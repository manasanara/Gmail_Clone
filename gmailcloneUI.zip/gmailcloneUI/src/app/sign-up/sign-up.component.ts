import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import ValidateForm from '../helpers/validatorform';
import { UserdataService } from '../services/userdata.service';
import { EmailcountService } from '../services/emailcount.service';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
   signupform!: FormGroup;
  constructor(private fb:FormBuilder,private userservice:UserdataService,private route:Router,private Activatedrouter:ActivatedRoute,private emailcount:EmailcountService) { }
  //  mailid:any;
  //  inboxcount:any;
  //  socialcount:any;
  //  primarycount:any;
  ngOnInit(): void {
    this.signupform = this.fb.group({
      Username :['',Validators.required],
      email :['',Validators.required],
      password:['',Validators.required],
      cpassword :['',Validators.required]
    })
  }
  onsignup(){
    const userdata ={
      email:this.signupform.value.email,
      password:this.signupform.value.password
    }
    this.route.navigate(['signin']);
    if(this.signupform.value){
    }
    else{
      //logic for throwing error
     ValidateForm.validateAllFormFields(this.signupform.value);
    }
    console.log("going");
    this.userservice.adduserdata(userdata).subscribe({ 
      next:(email) =>{
              console.log("mails");
      console.log(email);
             },
             error:(response)=>{
              console.log(response);
             }

      });
    // this.route.navigate(['signin']);
  }
  
}
