import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { EmailsService } from '../services/emails.service';
@Component({
  selector: 'app-composemail',
  templateUrl: './composemail.component.html',
  styleUrls: ['./composemail.component.css']
})
export class ComposemailComponent implements OnInit {
  composemail!: FormGroup;
  maildata: any = {};
  userdata: any = {};
  constructor(private fb: FormBuilder, public route: Router, public activatedroute: ActivatedRoute, public emailservice: EmailsService) { }
  sendmail() {
    this.userdata = {
      eto: this.composemail.value.toemail,
      efrom: this.composemail.value.fromemail,
      email: this.composemail.value.mail,
      subject: this.composemail.value.Subject,
      type: this.composemail.value.mtype
    }
    console.log(this.userdata);
    this.emailservice.addmaildata(this.userdata).subscribe((result) => {
    });
    alert("mail sent");
  }


  savedraft() {
    const userdata = {
      "eto": this.composemail.value.toemail,
      "efrom": this.composemail.value.fromemail,
      "email": this.composemail.value.mail,
      "subject": this.composemail.value.Subject,
      "type": "draft"
    }

    console.log(userdata);
    //adding emails to the api
    this.emailservice.addmaildata(userdata).subscribe((result) => {
      console.log(result);
    });
    alert("mail saved");
  }
  ngOnInit(): void {
    this.composemail = this.fb.group({
      toemail: ['', Validators.required],
      fromemail: ['', Validators.required],
      mail: ['', Validators.required],
      Subject: ['', Validators.required],
      mtype: ['', Validators.required]
    })
    // this.emaildata.getAllEmails().subscribe((res)=>{
    //   console.log(res);
    //  })
  }
}
