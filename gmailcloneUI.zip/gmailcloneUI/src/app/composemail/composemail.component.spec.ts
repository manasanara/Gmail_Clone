import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComposemailComponent } from './composemail.component';

describe('ComposemailComponent', () => {
  let component: ComposemailComponent;
  let fixture: ComponentFixture<ComposemailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComposemailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ComposemailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
