import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { InboxComponent } from '../inbox/inbox.component';
import { UserdataService } from '../services/userdata.service';
import { MatDialog } from '@angular/material/dialog';
import { ComposemailComponent } from '../composemail/composemail.component';
import { EmailcountService } from '../services/emailcount.service';
import { EmailsService } from '../services/emails.service';
import { DetailedmailComponent } from '../detailedmail/detailedmail.component';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  email:any;
  e:string="xyz@gmail.com";
   userdata : any=[];
   open:any=false;
  constructor(public Router:Router,public ActivatedRouter:ActivatedRoute,private userservice:UserdataService,private dialog:MatDialog,private emailcount:EmailcountService,public emailservice:EmailsService) { }
  dropdown(){
    this.open=true;
    console.log(this.open);
  }
  showdetail(subject:any){
    console.log(subject);
    this.Router.navigate(['detailedmail/',subject]);
  }
  primary(){
     this.Router.navigate(['primary/',this.email]);
  }
  social(){
    this.Router.navigate(['social/',this.email]);
 }
 promotions(){
  this.Router.navigate(['promotions/',this.email]);
}
inbox(){
  this.Router.navigate(['inbox/',this.email]);
}
sent(){
  this.Router.navigate(['sent/',this.email]);
}
drafts(){
  this.Router.navigate(['drafts/',this.email]);
}
opencomposemail(){
  console.log("compose");
  this.dialog.open(ComposemailComponent,{width:"80%",height:"80%"});
}
Emails:any;
users:any;
userid:any;
  ngOnInit(): void {
    this.email=this.ActivatedRouter.snapshot.params['id'];
    console.log(this.email);
    
  // emails service----------------
  this.emailservice.getAllmails().subscribe(res=>{
    this.Emails=res;
    console.log(this.Emails);
   })
  }

}
