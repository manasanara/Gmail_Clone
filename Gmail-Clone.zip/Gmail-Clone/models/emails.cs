﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Gmail_Clone.models
{
    public class emails
    {
        [Key]
        public int eid { get; set; }
        public string eto { get; set; }
        public string efrom { get; set; }
        public string email { get; set; }

        public string subject { get; set; }

        public string type { get; set; }
    }
}
