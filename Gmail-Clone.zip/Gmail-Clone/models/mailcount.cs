﻿using System.ComponentModel.DataAnnotations;

namespace Gmail_Clone.models
{
    public class mailcount
    {
        [Key]
        public string mailid { get; set; }
        public int inboxcount { get; set; }
        public int socialcount { get; set; }
        public int primarycount { get; set; }
    }
}
