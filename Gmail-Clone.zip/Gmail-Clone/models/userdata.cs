﻿using System.ComponentModel.DataAnnotations;

namespace Gmail_Clone.models
{
    public class userdata
    {
        public int id { get; set; }
        [Key]
        public string email { get; set; }
        public string password { get; set; }
    }
}
