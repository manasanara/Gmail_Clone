﻿using Gmail_Clone.Dbcontext;
using Gmail_Clone.models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gmail_Clone.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class emailcountController : Controller
    {
        private readonly GmailcloneDbContext _gmailclone;
        public emailcountController(GmailcloneDbContext gmailclone)
        {
            _gmailclone = gmailclone;
        }
        [HttpGet]
        public async Task<IActionResult> getalluserdata()
        {
            object userdata = await _gmailclone.emailcounts.ToListAsync();

            return Ok(userdata);
        }

        [HttpPost]
        public async Task<IActionResult> Adduserdata(mailcount userdata)
        {
            await _gmailclone.emailcounts.AddAsync(userdata);
            await _gmailclone.SaveChangesAsync();

            return Ok(userdata);
        }
    }
}
