﻿using Gmail_Clone.models;
using Microsoft.EntityFrameworkCore;

namespace Gmail_Clone.Dbcontext
{
    public class GmailcloneDbContext : DbContext
    {
        public GmailcloneDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<userdata> userdata { get; set; }
        public DbSet<emails> emails { get; set; }
        public DbSet<mailcount> emailcounts { get; set; }
    }
}
