﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Gmail_Clone.Migrations
{
    public partial class initialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "emailcounts",
                columns: table => new
                {
                    mailid = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    inboxcount = table.Column<int>(type: "int", nullable: false),
                    socialcount = table.Column<int>(type: "int", nullable: false),
                    primarycount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_emailcounts", x => x.mailid);
                });

            migrationBuilder.CreateTable(
                name: "emails",
                columns: table => new
                {
                    eid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    eto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    efrom = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    type = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_emails", x => x.eid);
                });

            migrationBuilder.CreateTable(
                name: "userdata",
                columns: table => new
                {
                    email = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    id = table.Column<int>(type: "int", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userdata", x => x.email);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "emailcounts");

            migrationBuilder.DropTable(
                name: "emails");

            migrationBuilder.DropTable(
                name: "userdata");
        }
    }
}
